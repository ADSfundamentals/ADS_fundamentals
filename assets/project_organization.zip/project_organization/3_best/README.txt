This project runs a toy path analysis.

- All source code lives in the 'code' directory.
- Raw data lives in 'data/raw'.
- Cleaned/processed data lives in 'data/processed'.
- The 'output' directory contains intermediate R objecs produced by the analysis.
- The 'figure' directory contains images files for all figures.
